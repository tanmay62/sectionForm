import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-checklist',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatButtonModule, MatInputModule, MatSelectModule, MatTabsModule],
  templateUrl: './checklist.component.html',
  styleUrls: ['./checklist.component.scss']
})

export class ChecklistComponent implements OnInit {
  @Input() sections: any[] = [];
  formGroups: { [key: string]: FormGroup } = {};
  paramTypes: string[] = ['Free Text', 'Date time', 'Dropdown', 'Yes/No'];
  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    if (this.sections.length > 0) {
      this.sections.forEach((section) => {
        this.formGroups[section.section] = this.fb.group({
          paramName: [section.paramName],
          paramType: [section.paramType],
          article: [section.article || []]
        });
      });
    }
  }

  save(): void {
    const savedData = Object.keys(this.formGroups).map((sectionName) => {
      return {
        section: sectionName,
        ...this.formGroups[sectionName].value
      };
    });

    console.log('Saved Data:', savedData);

    this.router.navigate(['/checklist-view'], { state: { data: savedData } });
  }
}
