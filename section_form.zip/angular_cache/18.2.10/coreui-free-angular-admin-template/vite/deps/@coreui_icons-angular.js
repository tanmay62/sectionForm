import {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
} from "./chunk-ZDH7R4GC.js";
import "./chunk-HQLFMGHA.js";
import "./chunk-7ZCOIREZ.js";
import "./chunk-4C6IJRBO.js";
import "./chunk-QOSOAIBK.js";
import "./chunk-6WCCERUZ.js";
export {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
};
//# sourceMappingURL=@coreui_icons-angular.js.map
