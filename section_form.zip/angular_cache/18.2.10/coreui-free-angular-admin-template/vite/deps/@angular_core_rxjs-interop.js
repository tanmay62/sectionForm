import {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
} from "./chunk-47F5BUHL.js";
import "./chunk-4C6IJRBO.js";
import "./chunk-QOSOAIBK.js";
import "./chunk-6WCCERUZ.js";
export {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
};
//# sourceMappingURL=@angular_core_rxjs-interop.js.map
