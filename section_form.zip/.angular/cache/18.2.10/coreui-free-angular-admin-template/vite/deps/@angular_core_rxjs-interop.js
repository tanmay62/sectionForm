import {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
} from "./chunk-XPFWWIFX.js";
import "./chunk-KNE7SPPC.js";
import "./chunk-QKNYWKTG.js";
import "./chunk-6WCCERUZ.js";
export {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
};
//# sourceMappingURL=@angular_core_rxjs-interop.js.map
