import {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
} from "./chunk-7PA7IDKM.js";
import "./chunk-MYPAVRSF.js";
import "./chunk-K7ELSIJ5.js";
import "./chunk-KNE7SPPC.js";
import "./chunk-QKNYWKTG.js";
import "./chunk-6WCCERUZ.js";
export {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
};
//# sourceMappingURL=@coreui_icons-angular.js.map
