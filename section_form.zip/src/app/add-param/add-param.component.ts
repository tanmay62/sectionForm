import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-add-param',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatButtonModule, MatInputModule, MatSelectModule],
  templateUrl: './add-param.component.html',
  styleUrls: ['./add-param.component.scss']
})
export class AddParamComponent {
  @Output() formSubmit = new EventEmitter<any>();

  addParamForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.addParamForm = this.fb.group({
      section: ['Section 1'],
      paramName: [''],
      paramType: [''],
      article: [[]]
    });
  }

  onSubmit(): void {
    console.log(this.addParamForm.value);
    this.formSubmit.emit(this.addParamForm.value);
    this.addParamForm.reset();
  }
}
